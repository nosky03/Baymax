import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color.white // Imposta lo sfondo bianco
                .ignoresSafeArea()
            Text("Baymax")
                .font(.largeTitle) // Rende il testo più grande
                .foregroundColor(.black) // Imposta il colore del testo in nero
        }
    }
}
